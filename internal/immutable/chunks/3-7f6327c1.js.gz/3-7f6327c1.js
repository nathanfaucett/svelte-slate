import{default as t}from"../components/pages/default/_page.svelte-e7cc0a38.js";export{t as component};
