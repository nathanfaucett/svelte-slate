import{default as t}from"../components/pages/_page.svelte-2dad6629.js";export{t as component};
