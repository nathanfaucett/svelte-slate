import{default as t}from"../components/pages/default/_page.svelte-29726988.js";export{t as component};
