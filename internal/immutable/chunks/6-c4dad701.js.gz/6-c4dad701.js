import{default as t}from"../components/pages/huge-document/_page.svelte-8900df3f.js";export{t as component};
