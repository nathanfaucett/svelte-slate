import{default as t}from"../components/pages/default/_page.svelte-052a3d56.js";export{t as component};
