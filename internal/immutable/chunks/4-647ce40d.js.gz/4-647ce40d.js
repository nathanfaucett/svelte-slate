import{default as t}from"../components/pages/default/_page.svelte-6e129bf0.js";export{t as component};
