import{default as t}from"../components/pages/chat/_page.svelte-31108f14.js";export{t as component};
