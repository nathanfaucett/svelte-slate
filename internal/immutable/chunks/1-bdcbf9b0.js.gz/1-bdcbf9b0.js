import{default as t}from"../components/error.svelte-fa83e406.js";export{t as component};
