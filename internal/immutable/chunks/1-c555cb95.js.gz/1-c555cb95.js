import{default as t}from"../components/error.svelte-f4be7092.js";export{t as component};
