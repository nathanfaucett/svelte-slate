import{default as t}from"../components/pages/richtext/_page.svelte-250f3300.js";export{t as component};
