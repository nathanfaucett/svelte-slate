import{default as t}from"../components/pages/plugins/_page.svelte-82768f55.js";export{t as component};
