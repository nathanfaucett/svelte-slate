import{default as t}from"../components/error.svelte-f7d9a150.js";export{t as component};
