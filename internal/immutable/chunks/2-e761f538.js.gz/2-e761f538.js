import{default as t}from"../components/pages/_page.svelte-f8c4c9c5.js";export{t as component};
