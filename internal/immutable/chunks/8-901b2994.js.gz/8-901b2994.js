import{default as t}from"../components/pages/richtext/_page.svelte-e0bd99f8.js";export{t as component};
