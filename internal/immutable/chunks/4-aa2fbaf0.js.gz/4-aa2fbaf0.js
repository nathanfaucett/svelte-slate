import{default as e}from"../components/pages/default/_page.svelte-1b35571a.js";import"./index-039b19e7.js";import"./index.es-5862db7f.js";import"./index-d1865c97.js";export{e as component};
