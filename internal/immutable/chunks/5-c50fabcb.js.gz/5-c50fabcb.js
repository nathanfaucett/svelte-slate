import{default as t}from"../components/pages/editor/_page.svelte-33e957ee.js";export{t as component};
