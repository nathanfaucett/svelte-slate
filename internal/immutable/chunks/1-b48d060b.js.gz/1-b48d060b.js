import{default as t}from"../components/error.svelte-0260bb09.js";export{t as component};
