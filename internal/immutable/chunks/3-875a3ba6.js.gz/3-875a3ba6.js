import{default as t}from"../components/pages/default/_page.svelte-ccc0cca9.js";export{t as component};
