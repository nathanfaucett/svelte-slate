import{default as t}from"../components/pages/huge-document/_page.svelte-ba04be56.js";export{t as component};
