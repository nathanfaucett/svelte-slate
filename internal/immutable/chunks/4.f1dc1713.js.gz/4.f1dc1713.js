import{default as t}from"../entry/huge-document-page.svelte.7a89a363.js";export{t as component};
