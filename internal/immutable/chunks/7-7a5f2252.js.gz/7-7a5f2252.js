import{default as t}from"../components/pages/plugins/_page.svelte-4e7c6e50.js";export{t as component};
