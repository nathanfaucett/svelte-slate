import{default as t}from"../components/pages/chat/_page.svelte-c7946cd9.js";export{t as component};
