import{default as t}from"../components/pages/plugins/_page.svelte-234c425b.js";export{t as component};
