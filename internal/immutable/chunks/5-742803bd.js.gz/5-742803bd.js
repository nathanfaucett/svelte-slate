import{default as t}from"../components/pages/plugins/_page.svelte-d350a435.js";export{t as component};
