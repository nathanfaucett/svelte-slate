import{default as t}from"../components/pages/huge-document/_page.svelte-48d1d480.js";export{t as component};
