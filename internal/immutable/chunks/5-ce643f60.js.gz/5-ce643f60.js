import{default as t}from"../components/pages/editor/_page.svelte-7f1c9bda.js";export{t as component};
