import{default as t}from"../components/pages/_page.svelte-e914c926.js";export{t as component};
