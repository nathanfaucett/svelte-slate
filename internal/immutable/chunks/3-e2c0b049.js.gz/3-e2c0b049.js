import{default as t}from"../components/pages/default/_page.svelte-5714836f.js";export{t as component};
