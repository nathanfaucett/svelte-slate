import{default as t}from"../entry/_page.svelte.da1749e8.js";export{t as component};
