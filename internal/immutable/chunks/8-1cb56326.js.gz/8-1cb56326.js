import{default as t}from"../components/pages/richtext/_page.svelte-4efa26c2.js";export{t as component};
