import{default as t}from"../components/pages/huge-document/_page.svelte-d472a18b.js";export{t as component};
