import{default as t}from"../components/pages/default/_page.svelte-e87518d7.js";export{t as component};
