import{default as t}from"../components/error.svelte-3388b02b.js";export{t as component};
