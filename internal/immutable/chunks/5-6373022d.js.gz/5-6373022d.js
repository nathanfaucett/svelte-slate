import{default as t}from"../components/pages/plugins/_page.svelte-dc8f58c9.js";export{t as component};
