import{default as t}from"../components/error.svelte-08f8e099.js";export{t as component};
