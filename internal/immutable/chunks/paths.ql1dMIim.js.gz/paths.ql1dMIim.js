const s=globalThis.__sveltekit_9vylbx?.base??"/svelte-slate",e=globalThis.__sveltekit_9vylbx?.assets??s;export{e as a,s as b};
