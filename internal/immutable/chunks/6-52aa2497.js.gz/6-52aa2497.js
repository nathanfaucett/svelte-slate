import{default as t}from"../components/pages/huge-document/_page.svelte-e2cfafd9.js";export{t as component};
