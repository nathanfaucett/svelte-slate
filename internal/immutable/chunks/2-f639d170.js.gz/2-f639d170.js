import{default as t}from"../components/pages/_page.svelte-df8171d9.js";export{t as component};
