import{default as t}from"../components/pages/huge-document/_page.svelte-49df3f75.js";export{t as component};
