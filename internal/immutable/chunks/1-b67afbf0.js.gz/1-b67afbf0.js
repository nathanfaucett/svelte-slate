import{default as t}from"../components/error.svelte-043a993e.js";export{t as component};
