import{default as t}from"../components/error.svelte-e592fda8.js";export{t as component};
