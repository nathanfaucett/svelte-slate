import{default as t}from"../components/pages/chat/_page.svelte-593e0b74.js";export{t as component};
