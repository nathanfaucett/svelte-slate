import{default as t}from"../components/pages/default/_page.svelte-e095f219.js";export{t as component};
