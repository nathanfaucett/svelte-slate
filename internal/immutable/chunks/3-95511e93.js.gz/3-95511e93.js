import{default as t}from"../components/pages/chat/_page.svelte-6f039cca.js";export{t as component};
