import{default as t}from"../components/pages/plugins/_page.svelte-a5a45435.js";export{t as component};
