import{default as t}from"../entry/error.svelte.6a63e4fa.js";export{t as component};
