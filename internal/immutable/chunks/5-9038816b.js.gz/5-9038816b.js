import{default as t}from"../components/pages/editor/_page.svelte-00811d5f.js";export{t as component};
