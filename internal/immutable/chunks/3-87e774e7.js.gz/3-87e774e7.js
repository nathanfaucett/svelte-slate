import{default as t}from"../components/pages/default/_page.svelte-0df6cc82.js";export{t as component};
