import{default as t}from"../components/pages/plugins/_page.svelte-6bac0d15.js";export{t as component};
