import{default as t}from"../components/pages/richtext/_page.svelte-19530912.js";export{t as component};
