import{default as t}from"../components/pages/chat/_page.svelte-fce589c5.js";export{t as component};
