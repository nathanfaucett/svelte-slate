import{default as t}from"../components/error.svelte-31f95c1b.js";export{t as component};
