import{default as t}from"../components/error.svelte-f1272b4d.js";export{t as component};
