import{default as t}from"../components/pages/huge-document/_page.svelte-f428e4d1.js";export{t as component};
