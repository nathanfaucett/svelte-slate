import{default as t}from"../components/pages/huge-document/_page.svelte-018d9655.js";export{t as component};
