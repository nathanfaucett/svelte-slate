import{default as t}from"../components/pages/default/_page.svelte-380ef4c7.js";export{t as component};
