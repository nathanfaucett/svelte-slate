import{default as t}from"../components/pages/huge-document/_page.svelte-a8d5546e.js";export{t as component};
