import{default as t}from"../components/pages/huge-document/_page.svelte-ec3727b8.js";export{t as component};
