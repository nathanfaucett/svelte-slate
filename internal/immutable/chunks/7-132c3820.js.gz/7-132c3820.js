import{default as t}from"../components/pages/plugins/_page.svelte-d481ce21.js";export{t as component};
