import{default as t}from"../components/pages/default/_page.svelte-2a60c62a.js";export{t as component};
