import{default as t}from"../components/pages/chat/_page.svelte-8a14bcef.js";export{t as component};
