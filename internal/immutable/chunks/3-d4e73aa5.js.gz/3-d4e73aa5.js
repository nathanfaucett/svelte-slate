import{default as t}from"../components/pages/default/_page.svelte-f20986f3.js";export{t as component};
