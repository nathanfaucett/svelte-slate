import{default as t}from"../components/error.svelte-f58b83f6.js";export{t as component};
