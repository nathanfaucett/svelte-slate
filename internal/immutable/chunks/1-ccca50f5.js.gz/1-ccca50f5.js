import{default as t}from"../components/error.svelte-48afbb16.js";export{t as component};
