import{default as t}from"../components/error.svelte-70cf2361.js";export{t as component};
