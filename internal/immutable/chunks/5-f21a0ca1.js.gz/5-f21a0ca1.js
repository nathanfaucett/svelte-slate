import{default as t}from"../components/pages/editor/_page.svelte-84a2d938.js";export{t as component};
