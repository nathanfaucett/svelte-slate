import{default as t}from"../components/pages/richtext/_page.svelte-def244f5.js";export{t as component};
