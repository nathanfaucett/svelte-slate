const e=!0,r=!1,s=Object.freeze(Object.defineProperty({__proto__:null,prerender:!0,ssr:!1},Symbol.toStringTag,{value:"Module"}));export{s as _,e as p,r as s};
