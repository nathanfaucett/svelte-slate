import{default as t}from"../components/pages/editor/_page.svelte-aa7d080a.js";export{t as component};
