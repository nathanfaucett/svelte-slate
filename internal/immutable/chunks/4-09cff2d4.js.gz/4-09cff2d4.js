import{default as t}from"../components/pages/default/_page.svelte-eb67ae15.js";export{t as component};
