import{default as t}from"../components/pages/richtext/_page.svelte-a42fd069.js";export{t as component};
