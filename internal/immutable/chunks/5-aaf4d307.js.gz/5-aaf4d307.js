import{default as t}from"../components/pages/plugins/_page.svelte-da9e03be.js";export{t as component};
