import{default as t}from"../components/pages/_page.svelte-6bd04cd2.js";export{t as component};
