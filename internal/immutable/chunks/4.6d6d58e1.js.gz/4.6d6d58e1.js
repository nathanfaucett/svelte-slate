import{default as t}from"../entry/huge-document-page.svelte.3cd7ad68.js";export{t as component};
