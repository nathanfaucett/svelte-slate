import{default as t}from"../components/pages/plugins/_page.svelte-5cc6b731.js";export{t as component};
