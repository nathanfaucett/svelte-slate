import{default as t}from"../components/error.svelte-1038638a.js";export{t as component};
