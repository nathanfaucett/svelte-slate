import{default as t}from"../components/pages/default/_page.svelte-731a6506.js";export{t as component};
