import{default as t}from"../entry/error.svelte.19cf03ef.js";export{t as component};
