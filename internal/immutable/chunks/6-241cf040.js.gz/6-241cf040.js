import{default as t}from"../components/pages/huge-document/_page.svelte-9d8eb266.js";export{t as component};
