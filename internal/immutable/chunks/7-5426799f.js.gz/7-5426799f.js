import{default as t}from"../components/pages/plugins/_page.svelte-f541870e.js";export{t as component};
