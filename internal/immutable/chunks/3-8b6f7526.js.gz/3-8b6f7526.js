import{default as t}from"../components/pages/default/_page.svelte-ede899f9.js";export{t as component};
