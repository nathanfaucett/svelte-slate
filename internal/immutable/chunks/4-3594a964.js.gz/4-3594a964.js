import{default as t}from"../components/pages/huge-document/_page.svelte-37dd18b8.js";export{t as component};
