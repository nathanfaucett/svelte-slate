import{default as t}from"../components/pages/plugins/_page.svelte-69a27193.js";export{t as component};
