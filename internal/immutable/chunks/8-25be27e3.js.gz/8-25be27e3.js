import{default as t}from"../components/pages/richtext/_page.svelte-b9af7cdf.js";export{t as component};
