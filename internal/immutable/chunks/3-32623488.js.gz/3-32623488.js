import{default as t}from"../components/pages/chat/_page.svelte-22d95aa4.js";export{t as component};
