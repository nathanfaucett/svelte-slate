import{default as t}from"../components/pages/editor/_page.svelte-929d00f8.js";export{t as component};
