import{default as t}from"../components/pages/default/_page.svelte-b6aed1c8.js";export{t as component};
