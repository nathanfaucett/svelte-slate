import{default as t}from"../entry/_page.svelte.3d011b8b.js";export{t as component};
