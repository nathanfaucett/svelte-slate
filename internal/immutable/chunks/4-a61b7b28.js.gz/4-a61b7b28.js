import{default as t}from"../components/pages/default/_page.svelte-f11f46dd.js";export{t as component};
