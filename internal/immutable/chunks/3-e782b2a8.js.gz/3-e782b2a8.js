import{default as t}from"../components/pages/default/_page.svelte-eb7c5a22.js";export{t as component};
