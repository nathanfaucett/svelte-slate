import{default as t}from"../components/pages/editor/_page.svelte-29f3c057.js";export{t as component};
