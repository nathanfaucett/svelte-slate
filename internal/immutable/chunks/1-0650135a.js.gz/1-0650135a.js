import{default as t}from"../components/error.svelte-40c2997f.js";export{t as component};
