let a="",e="",t="";function n(s){e=s.base,a=s.assets||e}function o(s){t=s}export{o as a,a as b,e as c,n as s,t as v};
