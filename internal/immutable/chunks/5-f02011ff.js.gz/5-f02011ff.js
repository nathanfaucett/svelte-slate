import{default as t}from"../components/pages/plugins/_page.svelte-0984a7d7.js";export{t as component};
