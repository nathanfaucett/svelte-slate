import{default as r}from"../components/pages/_page.svelte-c7c01f77.js";import"./index-039b19e7.js";import"./paths-846459bd.js";export{r as component};
