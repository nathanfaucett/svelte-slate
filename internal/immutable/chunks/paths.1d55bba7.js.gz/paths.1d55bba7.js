var s;const e=((s=globalThis.__sveltekit_ia509q)==null?void 0:s.base)??"/svelte-slate";var a;const t=((a=globalThis.__sveltekit_ia509q)==null?void 0:a.assets)??e;export{t as a,e as b};
