import{default as t}from"../entry/_page.svelte.bcf31d7c.js";export{t as component};
