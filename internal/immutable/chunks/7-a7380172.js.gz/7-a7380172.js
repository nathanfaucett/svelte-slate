import{default as t}from"../components/pages/plugins/_page.svelte-3e38c645.js";export{t as component};
