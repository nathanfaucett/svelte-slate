import{default as t}from"../components/pages/richtext/_page.svelte-4495494b.js";export{t as component};
