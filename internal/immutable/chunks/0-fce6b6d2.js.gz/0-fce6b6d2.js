import{default as t}from"../components/pages/_layout.svelte-3e9d7515.js";export{t as component};
