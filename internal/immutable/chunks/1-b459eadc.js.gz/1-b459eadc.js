import{default as t}from"../components/error.svelte-0ba20cd2.js";export{t as component};
