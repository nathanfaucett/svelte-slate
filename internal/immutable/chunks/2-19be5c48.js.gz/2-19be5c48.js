import{default as t}from"../components/pages/_page.svelte-30842811.js";export{t as component};
