import{default as t}from"../components/pages/default/_page.svelte-316726b7.js";export{t as component};
