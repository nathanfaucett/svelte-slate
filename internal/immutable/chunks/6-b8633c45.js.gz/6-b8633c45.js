import{default as t}from"../components/pages/huge-document/_page.svelte-c5ff2039.js";export{t as component};
