import{default as t}from"../components/pages/_page.svelte-9c820249.js";export{t as component};
