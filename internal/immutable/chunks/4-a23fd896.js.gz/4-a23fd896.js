import{default as t}from"../components/pages/huge-document/_page.svelte-f9e8f1f1.js";export{t as component};
