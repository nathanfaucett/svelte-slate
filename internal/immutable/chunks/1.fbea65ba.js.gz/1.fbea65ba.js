import{default as t}from"../entry/error.svelte.e76e3e46.js";export{t as component};
