import{default as t}from"../components/pages/huge-document/_page.svelte-41b5739f.js";export{t as component};
