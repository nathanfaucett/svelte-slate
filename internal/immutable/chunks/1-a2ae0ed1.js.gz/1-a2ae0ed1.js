import{default as t}from"../components/error.svelte-d46e1c2b.js";export{t as component};
