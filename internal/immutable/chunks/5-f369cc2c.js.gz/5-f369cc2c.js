import{default as t}from"../components/pages/plugins/_page.svelte-d34d0091.js";export{t as component};
