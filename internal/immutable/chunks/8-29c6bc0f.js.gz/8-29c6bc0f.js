import{default as t}from"../components/pages/richtext/_page.svelte-35289176.js";export{t as component};
