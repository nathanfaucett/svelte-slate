import{default as t}from"../components/pages/plugins/_page.svelte-1e9efe87.js";export{t as component};
