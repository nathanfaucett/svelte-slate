import{default as t}from"../components/pages/richtext/_page.svelte-d8c30526.js";export{t as component};
