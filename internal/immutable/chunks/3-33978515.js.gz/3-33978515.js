import{default as t}from"../components/pages/default/_page.svelte-f20f0c35.js";export{t as component};
