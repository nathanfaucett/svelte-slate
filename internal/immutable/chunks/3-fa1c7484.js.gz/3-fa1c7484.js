import{default as t}from"../components/pages/chat/_page.svelte-3e67e9a5.js";export{t as component};
