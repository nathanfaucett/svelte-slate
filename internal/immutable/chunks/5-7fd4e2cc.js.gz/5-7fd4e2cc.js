import{default as t}from"../components/pages/editor/_page.svelte-ca5e20df.js";export{t as component};
