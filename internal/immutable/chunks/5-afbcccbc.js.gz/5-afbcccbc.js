import{default as t}from"../components/pages/plugins/_page.svelte-6d01d2d6.js";export{t as component};
