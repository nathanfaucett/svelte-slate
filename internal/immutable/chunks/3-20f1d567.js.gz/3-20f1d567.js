import{default as t}from"../components/pages/default/_page.svelte-929a72f0.js";export{t as component};
