import{default as t}from"../components/pages/richtext/_page.svelte-3ea82a41.js";export{t as component};
