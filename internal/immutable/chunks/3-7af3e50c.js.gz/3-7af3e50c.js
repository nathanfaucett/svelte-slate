import{default as t}from"../components/pages/default/_page.svelte-1bf6beae.js";export{t as component};
