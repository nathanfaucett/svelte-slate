import{default as t}from"../components/pages/_page.svelte-3e7f2067.js";export{t as component};
