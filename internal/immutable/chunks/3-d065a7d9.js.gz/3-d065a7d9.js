import{default as t}from"../components/pages/chat/_page.svelte-69819c6f.js";export{t as component};
