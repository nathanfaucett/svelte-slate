import{default as t}from"../components/pages/huge-document/_page.svelte-3deba07c.js";export{t as component};
