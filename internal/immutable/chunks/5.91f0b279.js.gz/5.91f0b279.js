import{default as t}from"../entry/plugins-page.svelte.8dea3fb3.js";export{t as component};
