import{default as t}from"../components/pages/plugins/_page.svelte-74268fad.js";export{t as component};
