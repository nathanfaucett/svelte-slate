import{default as t}from"../components/pages/default/_page.svelte-b07a7b29.js";export{t as component};
