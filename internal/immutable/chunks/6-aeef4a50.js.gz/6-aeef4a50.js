import{default as t}from"../components/pages/huge-document/_page.svelte-75fca009.js";export{t as component};
