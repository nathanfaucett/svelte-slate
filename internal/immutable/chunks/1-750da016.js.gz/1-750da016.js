import{default as t}from"../components/error.svelte-31655f6f.js";export{t as component};
