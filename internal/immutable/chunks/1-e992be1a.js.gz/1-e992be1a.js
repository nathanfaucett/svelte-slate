import{default as t}from"../components/error.svelte-bb4662ce.js";export{t as component};
