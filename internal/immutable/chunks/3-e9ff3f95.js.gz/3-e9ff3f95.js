import{default as t}from"../components/pages/default/_page.svelte-d948a21d.js";export{t as component};
