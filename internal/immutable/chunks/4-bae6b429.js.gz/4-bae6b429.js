import{default as t}from"../components/pages/huge-document/_page.svelte-f2f70f83.js";export{t as component};
