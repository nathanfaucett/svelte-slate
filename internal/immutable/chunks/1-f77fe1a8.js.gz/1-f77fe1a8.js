import{default as t}from"../components/error.svelte-862ebd82.js";export{t as component};
