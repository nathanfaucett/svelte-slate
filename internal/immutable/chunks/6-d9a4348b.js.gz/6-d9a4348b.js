import{default as t}from"../components/pages/huge-document/_page.svelte-88f1c627.js";export{t as component};
