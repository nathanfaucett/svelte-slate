import{default as t}from"../entry/default-page.svelte.50e818d6.js";export{t as component};
