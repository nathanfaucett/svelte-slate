import{default as e}from"../components/pages/_layout.svelte-1979f8a4.js";import"./index-039b19e7.js";import"./paths-846459bd.js";import"./IconBase-3c858425.js";export{e as component};
