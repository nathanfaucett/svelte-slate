import{default as t}from"../components/pages/huge-document/_page.svelte-f77d9acd.js";export{t as component};
