import{default as t}from"../components/pages/plugins/_page.svelte-31343bc9.js";export{t as component};
