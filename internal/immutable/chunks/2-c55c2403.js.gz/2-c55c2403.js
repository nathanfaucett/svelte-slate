import{default as t}from"../components/pages/_page.svelte-48ce5b29.js";export{t as component};
