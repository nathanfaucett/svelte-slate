import{default as t}from"../components/error.svelte-10c04a4a.js";export{t as component};
