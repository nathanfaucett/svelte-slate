import{default as t}from"../components/error.svelte-814e00a6.js";export{t as component};
