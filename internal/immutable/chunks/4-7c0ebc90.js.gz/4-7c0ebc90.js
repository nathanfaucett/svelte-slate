import{default as t}from"../components/pages/default/_page.svelte-28a7cdf2.js";export{t as component};
