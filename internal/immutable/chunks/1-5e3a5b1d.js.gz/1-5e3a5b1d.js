import{default as t}from"../components/error.svelte-0dc18895.js";export{t as component};
