import{default as t}from"../components/pages/default/_page.svelte-fffa8893.js";export{t as component};
