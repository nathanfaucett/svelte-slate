import{default as t}from"../components/pages/editor/_page.svelte-5f6a5fbf.js";export{t as component};
