const s=globalThis.__sveltekit_1bcq636?.base??"/svelte-slate",e=globalThis.__sveltekit_1bcq636?.assets??s;export{e as a,s as b};
