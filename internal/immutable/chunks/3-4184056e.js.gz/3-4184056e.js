import{default as t}from"../components/pages/default/_page.svelte-059a6d20.js";export{t as component};
