import{default as t}from"../components/pages/huge-document/_page.svelte-a386a5cc.js";export{t as component};
