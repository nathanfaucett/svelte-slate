import{default as t}from"../entry/default-page.svelte.f086f6af.js";export{t as component};
