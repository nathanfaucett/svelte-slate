import{default as t}from"../entry/error.svelte.2ecefa71.js";export{t as component};
