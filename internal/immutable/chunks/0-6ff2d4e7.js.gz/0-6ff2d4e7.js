import{_ as r}from"./_layout-38454bf1.js";import{default as t}from"../components/pages/_layout.svelte-4ced1d96.js";export{t as component,r as universal};
