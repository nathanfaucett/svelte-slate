import{default as t}from"../components/pages/plugins/_page.svelte-5a8a814a.js";export{t as component};
