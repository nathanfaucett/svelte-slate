import{default as e}from"../components/pages/_layout.svelte-020641a8.js";import"./index-039b19e7.js";import"./paths-846459bd.js";import"./IconBase-3c858425.js";export{e as component};
