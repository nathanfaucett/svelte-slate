import{default as t}from"../entry/plugins-page.svelte.2d8046dd.js";export{t as component};
