import{default as t}from"../components/pages/_page.svelte-77c4fc08.js";export{t as component};
