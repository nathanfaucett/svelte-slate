import{default as t}from"../components/pages/chat/_page.svelte-53507314.js";export{t as component};
