import{default as t}from"../components/pages/richtext/_page.svelte-0d0b1a10.js";export{t as component};
