import{default as t}from"../components/pages/huge-document/_page.svelte-e66be7d2.js";export{t as component};
