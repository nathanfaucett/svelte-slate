import{default as t}from"../components/pages/_page.svelte-b0627fe4.js";export{t as component};
