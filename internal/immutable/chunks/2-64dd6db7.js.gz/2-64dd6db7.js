import{default as t}from"../components/pages/_page.svelte-7a388703.js";export{t as component};
