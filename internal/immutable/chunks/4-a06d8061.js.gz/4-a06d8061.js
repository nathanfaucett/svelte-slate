import{default as t}from"../components/pages/default/_page.svelte-6712b82c.js";export{t as component};
