import{default as t}from"../components/pages/huge-document/_page.svelte-d4fbb211.js";export{t as component};
