import{default as t}from"../components/pages/huge-document/_page.svelte-fd438147.js";export{t as component};
