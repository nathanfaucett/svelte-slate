import{default as t}from"../components/pages/chat/_page.svelte-c528dba4.js";export{t as component};
