import{default as t}from"../components/pages/huge-document/_page.svelte-2cba8849.js";export{t as component};
