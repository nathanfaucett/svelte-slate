import{default as t}from"../components/pages/chat/_page.svelte-90b42d5d.js";export{t as component};
