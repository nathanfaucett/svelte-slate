import{default as t}from"../components/pages/chat/_page.svelte-bb7ae9cb.js";export{t as component};
