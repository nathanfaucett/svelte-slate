import{default as t}from"../components/pages/_page.svelte-e414f8df.js";export{t as component};
