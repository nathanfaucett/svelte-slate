import{default as t}from"../components/pages/chat/_page.svelte-831813c4.js";export{t as component};
