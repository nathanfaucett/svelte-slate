import{default as t}from"../components/pages/plugins/_page.svelte-b20c06e1.js";export{t as component};
