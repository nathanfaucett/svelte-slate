import{default as t}from"../components/pages/plugins/_page.svelte-d315a57c.js";export{t as component};
