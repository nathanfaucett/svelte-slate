import{default as t}from"../components/pages/default/_page.svelte-e75b1535.js";export{t as component};
