import{default as t}from"../components/pages/richtext/_page.svelte-9808ccfa.js";export{t as component};
