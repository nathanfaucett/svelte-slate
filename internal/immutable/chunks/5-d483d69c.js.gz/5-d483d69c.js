import{default as t}from"../components/pages/editor/_page.svelte-2b84a76a.js";export{t as component};
