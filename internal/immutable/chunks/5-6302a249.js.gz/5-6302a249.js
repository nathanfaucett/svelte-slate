import{default as t}from"../components/pages/editor/_page.svelte-05a58cf6.js";export{t as component};
