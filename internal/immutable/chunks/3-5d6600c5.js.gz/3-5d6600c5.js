import{default as t}from"../components/pages/chat/_page.svelte-f8cc5768.js";export{t as component};
