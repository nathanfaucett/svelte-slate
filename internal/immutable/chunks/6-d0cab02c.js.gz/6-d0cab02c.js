import{default as t}from"../components/pages/huge-document/_page.svelte-0ce9b5f7.js";export{t as component};
