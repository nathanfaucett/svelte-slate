import{default as t}from"../components/pages/chat/_page.svelte-3eb475da.js";export{t as component};
