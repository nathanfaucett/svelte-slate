import{default as t}from"../components/error.svelte-d6db5275.js";export{t as component};
