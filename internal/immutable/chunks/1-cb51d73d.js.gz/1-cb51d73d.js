import{default as t}from"../components/error.svelte-9228dec0.js";export{t as component};
