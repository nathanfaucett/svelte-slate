import{default as t}from"../components/pages/default/_page.svelte-99b25e71.js";export{t as component};
