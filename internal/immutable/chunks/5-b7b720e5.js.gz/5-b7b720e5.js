import{default as t}from"../components/pages/editor/_page.svelte-b305bd0c.js";export{t as component};
