import{default as t}from"../components/pages/_page.svelte-069928c5.js";export{t as component};
