import{default as t}from"../components/pages/default/_page.svelte-4d7dc22c.js";export{t as component};
