import{default as t}from"../components/error.svelte-a9d55bac.js";export{t as component};
