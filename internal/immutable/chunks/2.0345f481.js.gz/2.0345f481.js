import{default as t}from"../entry/_page.svelte.e84698a2.js";export{t as component};
