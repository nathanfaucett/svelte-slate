import{default as t}from"../components/pages/plugins/_page.svelte-04b495fd.js";export{t as component};
