import{default as t}from"../components/pages/chat/_page.svelte-abbd4613.js";export{t as component};
