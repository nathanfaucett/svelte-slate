import{default as t}from"../components/pages/default/_page.svelte-c377d2e2.js";export{t as component};
