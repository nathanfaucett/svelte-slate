import{default as t}from"../components/pages/huge-document/_page.svelte-f8e801ed.js";export{t as component};
