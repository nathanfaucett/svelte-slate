import{default as t}from"../components/pages/plugins/_page.svelte-fb69ff72.js";export{t as component};
