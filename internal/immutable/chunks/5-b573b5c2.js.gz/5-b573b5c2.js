import{default as t}from"../components/pages/plugins/_page.svelte-55dbedd0.js";export{t as component};
