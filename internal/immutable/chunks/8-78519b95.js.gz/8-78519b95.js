import{default as t}from"../components/pages/richtext/_page.svelte-795d0094.js";export{t as component};
