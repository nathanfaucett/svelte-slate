import{default as t}from"../components/pages/editor/_page.svelte-9a69c6a3.js";export{t as component};
