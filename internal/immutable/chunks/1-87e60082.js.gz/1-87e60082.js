import{default as t}from"../components/error.svelte-f3058ab0.js";export{t as component};
