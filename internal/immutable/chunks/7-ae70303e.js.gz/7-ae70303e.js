import{default as t}from"../components/pages/plugins/_page.svelte-b977ab2d.js";export{t as component};
