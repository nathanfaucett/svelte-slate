import{default as t}from"../components/error.svelte-74551a71.js";export{t as component};
