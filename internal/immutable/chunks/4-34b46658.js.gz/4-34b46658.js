import{default as t}from"../components/pages/default/_page.svelte-e530cf34.js";export{t as component};
