import{default as t}from"../components/pages/huge-document/_page.svelte-d97fc061.js";export{t as component};
