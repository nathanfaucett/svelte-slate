import{default as t}from"../components/pages/richtext/_page.svelte-bb782b7a.js";export{t as component};
