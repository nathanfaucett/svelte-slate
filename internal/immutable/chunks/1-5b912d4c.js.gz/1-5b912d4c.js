import{default as t}from"../components/error.svelte-d33bb2ea.js";export{t as component};
