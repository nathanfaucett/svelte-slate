import{default as t}from"../components/pages/huge-document/_page.svelte-50cdd3e8.js";export{t as component};
