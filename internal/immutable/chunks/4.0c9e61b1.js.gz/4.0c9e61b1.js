import{default as t}from"../entry/huge-document-page.svelte.23d15793.js";export{t as component};
