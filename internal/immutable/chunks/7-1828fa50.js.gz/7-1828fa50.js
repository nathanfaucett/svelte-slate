import{default as t}from"../components/pages/plugins/_page.svelte-a7b9561d.js";export{t as component};
