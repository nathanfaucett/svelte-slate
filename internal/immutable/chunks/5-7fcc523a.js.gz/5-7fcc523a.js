import{default as t}from"../components/pages/plugins/_page.svelte-159a70ec.js";export{t as component};
