import{default as t}from"../components/pages/plugins/_page.svelte-c07a3109.js";export{t as component};
