import{default as t}from"../components/pages/chat/_page.svelte-440cb160.js";export{t as component};
