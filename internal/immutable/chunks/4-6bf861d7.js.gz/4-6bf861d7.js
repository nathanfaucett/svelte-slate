import{default as t}from"../components/pages/huge-document/_page.svelte-5635fb1c.js";export{t as component};
