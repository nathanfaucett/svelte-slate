import{default as t}from"../components/error.svelte-0ac5ee8d.js";export{t as component};
