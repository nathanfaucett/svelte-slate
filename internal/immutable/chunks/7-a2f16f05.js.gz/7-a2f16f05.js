import{default as t}from"../components/pages/plugins/_page.svelte-d2e8bafb.js";export{t as component};
