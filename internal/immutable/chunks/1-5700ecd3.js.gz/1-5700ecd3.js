import{default as t}from"../components/error.svelte-ebcad67f.js";export{t as component};
