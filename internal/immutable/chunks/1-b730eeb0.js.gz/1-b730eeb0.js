import{default as t}from"../components/error.svelte-b626d5d9.js";export{t as component};
