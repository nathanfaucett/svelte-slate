import{default as t}from"../components/error.svelte-a73e1752.js";export{t as component};
