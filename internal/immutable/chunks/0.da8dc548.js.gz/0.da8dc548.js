import{_ as r}from"./_layout.38454bf1.js";import{default as t}from"../entry/_layout.svelte.ad399b0f.js";export{t as component,r as universal};
