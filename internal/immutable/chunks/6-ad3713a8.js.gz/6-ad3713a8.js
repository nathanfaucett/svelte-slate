import{default as t}from"../components/pages/huge-document/_page.svelte-b53d9d00.js";export{t as component};
