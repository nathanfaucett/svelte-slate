import{default as t}from"../components/pages/chat/_page.svelte-f2a9a327.js";export{t as component};
