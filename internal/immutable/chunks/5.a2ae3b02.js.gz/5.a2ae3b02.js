import{default as t}from"../entry/plugins-page.svelte.8123b8cb.js";export{t as component};
