import{a as t}from"../chunks/entry.BVn6bhzE.js";export{t as start};
