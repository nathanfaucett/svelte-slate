import{p}from"../../chunks/_layout-c2405b24.js";export{p as prerender};
